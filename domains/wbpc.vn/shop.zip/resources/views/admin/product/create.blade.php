@extends('admin.layouts.master')
@section('admin_title','Thêm mới sản phẩm')
@section('content')
    <div class="container-fluid">
         @include('admin.product.form')
        <!-- panel// -->
    </div>
@stop