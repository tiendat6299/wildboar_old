<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class attentions extends Model
{
    protected $table = "attentions";
}
