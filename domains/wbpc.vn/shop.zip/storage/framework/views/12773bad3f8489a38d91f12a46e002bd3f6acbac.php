<?php $__env->startSection('admin_title','Quản lý thành viên'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
        </div>
        <div class="row">
            <div class="col-md-9" style="margin-bottom: 20px;">
                <div class="form-filter">
                    <form action="" class="form-inline">
                        <div class="form-group">
                            <input type="text" class="form-control" name="id" placeholder="ID" value="<?php echo e(Request::get('id')); ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="n" placeholder="Name" value="<?php echo e(Request::get('n')); ?>">
                        </div>
                        <button class="btn btn-primary"><i class="fa fa-filter"></i> Lọc</button>
                    </form>
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-hover table-responsive table-bordered">
                        <thead>
                        <tr>
                            <th width="2%">ID</th>
                            <th width="7%" class="text-center">Name</th>
                            <th width="10%" class="text-center">Email</th>
                            <th width="5%" class="text-center">Phone</th>
                            <th width="10%" class="text-center">Address</th>
                            <th width="5%" class="text-center">ACTIONS</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(isset($users)): ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-row-id="956" class="row_facebook" id="row_facebook_956">
                                    <td><?php echo e($user->id); ?></td>
                                    <td>
                                        <div>
                                            <a href="" target="_blank">
                                                <?php echo e($user->full_name); ?>

                                            </a>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <p><?php echo e($user->email); ?></p>
                                    </td>
                                    <td align="center">
                                        <p><?php echo e($user->phone); ?></p>
                                    </td>
                                    <td align="center">
                                        <p><?php echo e($user->address); ?></p>
                                    </td>
                                    <td align="center">
                                        <div class="dropdown">
                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1"
                                                    data-toggle="dropdown">
                                                Actions
                                                <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu source-menu-action" role="menu" aria-labelledby="dropdownMenu1">
                                                <li role="presentation">
                                                    <a role="menuitem" href="<?php echo e(route('admin.get.user.delete', $user->id)); ?>">Delete</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="pagination-view">
                        <?php echo e($users->currentPage()); ?> - <?php echo e($users->perPage()); ?>/<?php echo e($users->total()); ?> records
                        <div class="pull-right">
                            <?php echo $users->appends($query ?? [])->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>