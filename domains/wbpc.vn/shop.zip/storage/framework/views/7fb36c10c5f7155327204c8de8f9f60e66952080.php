<?php $__env->startSection('admin_title','Quản lý Bill'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
        </div>
        <div class="row">
            <div class="col-md-9" style="margin-bottom: 20px;">
                <div class="form-filter">
                    <form action="" class="form-inline">
                        <div class="form-group">
                            <input type="text" class="form-control" name="id" placeholder="ID" value="<?php echo e(Request::get('id')); ?>">
                        </div>
                        <button class="btn btn-primary">Lọc</button>
                    </form>
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-hover table-responsive table-bordered">
                        <thead>
                        <tr>
                            <th width="2%">ID</th>
                            <th width="5%">Customer</th>
                            <th width="3%" class="text-center">Total</th>
                            <th width="12%" class="text-center">Note</th>
                            <th width="5%" class="text-center">ACTIONS</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($bill)): ?>
                                <?php $__currentLoopData = $bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($bill->id); ?>

                                    </td>
                                    <td>
                                        <?php echo e($bill->customer->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($bill->total); ?>

                                    </td>
                                    <td>
                                        <?php echo e($bill->note); ?>

                                    </td>
                                    <td align="center">
                                        <div class="dropdown">
                                            <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
                                                Đã xong
                                            <span class="caret"></span>
                                            </button>
                                            <ul class="dropdown-menu source-menu-action" role="menu" aria-labelledby="dropdownMenu1">
                                                <li role="presentation"><a role="menuitem" href="<?php echo e(route('admin.get.bill.delete', $bill->id)); ?>">Delete</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>