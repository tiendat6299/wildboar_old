 <footer class="footer-spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__about__logo">
                            <a href="./index.html"><img src="source/assets/dest/images/icon.jpg" alt="" style="height: 100px"></a>
                        </div>
                        <ul>
                            <li>Address:26B N4 Tập thể binh đoàn 12, Ngõ Thịnh Quang, Đống Đa, Hà Nội</li>
                            <li>Phone: +8424609333 Hoặc +8464099596</li>
                            <li>Email: chuoi0223@gmail.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
                    <div class="footer__widget">
                        <h6>Các Đường Dẫn Về Thông Tin Cửa Hàng</h6>
                        <ul>
                            <li><a href="https://www.facebook.com/WBStorevn/about">Về WildBoarStore</a></li>
                            <li><a href="<?php echo e(route('lienhe')); ?>">Vị Trí Cửa Hàng</a></li>
                            <li>Ship tận nhà tại Hà Nội</a></li>
                            <li>Mọi đơn vận chuyển đều đến nơi trong 3 ngày kể từ ngày đặt hàng</li>
                            
                        </ul>
                        <ul>
                            <li>Phục vụ, kiểm tra tại nhà trong 7 ngày đầu lấy hàng tại Hà Nội</a></li>
                            <li><a href="<?php echo e(route('lienhe')); ?>">Liên Hệ Với Chúng Tôi</a></li>
                        </ul>
                    </div>
                </div>
                
            </div>
            
        </div>
    </footer>