<?php $__env->startSection('content'); ?>
	<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Gợi ý mua hàng</h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="index.html">Trang chủ</a> / <span>Gợi ý mua hàng</span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<br>
	<!-- số lượng đánh giá & đặt hàng -->

	<div class="space50"><br></div>
			<hr style="height: 1px; background-color: black;" />
			<div class="space50"><br></div>
			<h2 class="text-center wow fadeInDown">Chỉ số</h2>
			<div class="space20"><br></div>
			<h4 class="text-center wow fadeInLeft">Những thống kê ghi lại quá chình từ lúc trang web hoạt động </h4>
			<div class="space35"><br></div>

			<div class="row">
				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-user"></i></p>
						<p class="beta-counter-value timer numbers" id="span_customer">0</p>
						<p class="beta-counter-title">Clients Satisfied</p>
					</div>
				</div>

				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-birthday-cake"></i></p>
						<p class="beta-counter-value timer numbers" id="span_cake">0</p>
						<p class="beta-counter-title">Amazing Works</p>
					</div>
				</div>

				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-cart-plus"></i></p>
						<p class="beta-counter-value timer numbers" id="span_bill">0</p>
						<p class="beta-counter-title">Support Hours</p>
					</div>
				</div>

				<div class="col-sm-2 col-sm-push-2">
					<div class="beta-counter">
						<p class="beta-counter-icon"><i class="fa fa-undo"></i></p>
						<p class="beta-counter-value timer numbers" id='span_reorder'>0</p>
						<p class="beta-counter-title">New Projects</p>
					</div>
				</div>
			</div> 

			<br>
			<br>
			<br>
			<br>
	<div class="container">
		<div id="content">
			<div class="our-history">
				<h2 class="text-center wow fadeInDown">Những ngày đặc biệt</h2>
				<div class="space35"><br></div>

				<div class="history-slider">
					<div class="history-navigation">
						<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a data-slide-index="<?php echo e($key); ?>" href="" class="circle">
								<span class="auto-center"><?php echo e($each->day); ?></span>
							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</div>

					<div class="history-slides">
						<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div> 
								<div class="row">
								<div class="col-sm-5">
									<img src="<?php echo e($each->img); ?>" alt="">
								</div>
								<div class="col-sm-7">
									<h5 class="other-title"><?php echo e($each->nd); ?></h5>
									<p><?php echo e($each->note); ?></p>
								</div>
								</div> 
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>

			
			
			
			<div class="space50"><br></div>
			<hr style="height: 1px; background-color: black;" />
			<div class="space50"><br></div>
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.easing.min.js')); ?>"></script>
<script type="text/javascript">
function getNumber(id_span,number) {
    var $el = $(`#${id_span}`);
    
    $({percentage: 0}).stop(true).animate({percentage: number}, {
        duration : 2000,
        easing: "easeOutExpo",
        step: function (percentage) {
            // percentage with 1 decimal;
            var percentageVal = Math.round(this.percentage);
            
            $el.text(percentageVal);
        }
    }).promise().done(function () {
        $el.text(number);
    });
}
$(document).ready(function(){
    $.ajax({
        url: '<?php echo e(route('ajax_info')); ?>',
        type: 'GET',
        dataType: 'json',
    })
    .done(function(response) {
        getNumber('span_customer',response.number_customer);
        getNumber('span_cake',response.number_cake);
        getNumber('span_bill',response.number_bill);
        getNumber('span_reorder',response.number_reorder);
    });
});

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>