<?php $__env->startSection('admin_title','Cập nhật sản phẩm'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
    <?php echo $__env->make('admin.product.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- panel// -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>