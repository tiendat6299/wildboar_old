-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th7 24, 2020 lúc 03:45 AM
-- Phiên bản máy phục vụ: 10.4.13-MariaDB
-- Phiên bản PHP: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `testkeytoken`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `avatar`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Đinh Trọng Đức', 'chuoi0223@gmail.com', NULL, '$2y$10$NwmbRqe8CUBtBTIBoebfkuZ6JN1A2Foz8XzNkYs895pAGP/ssAz2i', 'Pjh70BekEXi3qafUmAfuTtPhTgU8V7Zwb3YF8IBMpURLUhcXTj7SeTaeqXJV', NULL, '2019-05-14 16:25:10');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bills`
--

CREATE TABLE `bills` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_customer` int(11) DEFAULT NULL,
  `date_order` date DEFAULT NULL,
  `total` float DEFAULT NULL COMMENT 'tổng tiền',
  `payment` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'hình thức thanh toán',
  `note` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `bills`
--

INSERT INTO `bills` (`id`, `id_customer`, `date_order`, `total`, `payment`, `note`, `created_at`, `updated_at`) VALUES
(23, 23, '2020-07-20', 3650000, 'COD', 'trước khi giao phải gọi trước 1h', '2020-07-20 10:56:21', '2020-07-20 10:56:21'),
(22, 22, '2020-07-20', 1650000, 'COD', NULL, '2020-07-20 10:54:04', '2020-07-20 10:54:04');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `bill_detail`
--

CREATE TABLE `bill_detail` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_bill` int(10) NOT NULL,
  `id_product` int(10) NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'số lượng',
  `unit_price` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Đang đổ dữ liệu cho bảng `bill_detail`
--

INSERT INTO `bill_detail` (`id`, `id_bill`, `id_product`, `quantity`, `unit_price`, `created_at`, `updated_at`) VALUES
(26, 23, 69, 1, 3650000, '2020-07-20 10:56:21', '2020-07-20 10:56:21'),
(25, 22, 66, 1, 1650000, '2020-07-20 10:54:04', '2020-07-20 10:54:04');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customer`
--

CREATE TABLE `customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `address`, `phone_number`, `note`, `created_at`, `updated_at`) VALUES
(15, 'ê', 'huongnguyen@gmail.com', 'e', 'e', '', '2017-03-24 07:14:32', '2017-03-24 07:14:32'),
(14, 'hhh', 'huongnguyen@gmail.com', 'Lê thị riêng', '99999999999999999', '', '2017-03-23 04:46:05', '2017-03-23 04:46:05'),
(13, 'Hương Hương', 'huongnguyenak96@gmail.com', 'Lê Thị Riêng, Quận 1', '23456789', '', '2017-03-21 07:29:31', '2017-03-21 07:29:31'),
(12, 'Khoa phạm', 'khoapham@gmail.com', 'Lê thị riêng', '1234567890', '', '2017-03-21 07:20:07', '2017-03-21 07:20:07'),
(11, 'Hương Hương', 'huongnguyenak96@gmail.com', 'Lê Thị Riêng, Quận 1', '234567890-', '', '2017-03-21 07:16:09', '2017-03-21 07:16:09'),
(16, 'tungsweet', 'nganthoi@gmail.com', 'mars', '0199999933', '', '2020-07-03 10:17:41', '2020-07-03 10:17:41'),
(17, 'tungsweet', 'nganthoi@gmail.com', 'mars', '0199999933', '', '2020-07-13 09:29:16', '2020-07-13 09:29:16'),
(18, 'tungsweet', 'nganthoi@gmail.com', 'mars', '0199999933', '', '2020-07-15 09:02:56', '2020-07-15 09:02:56'),
(19, 'tungsweet', 'nganthoi@gmail.com', 'mars', '0199999933', '', '2020-07-15 09:21:48', '2020-07-15 09:21:48'),
(20, 'tungsweet', 'nganthoi@gmail.com', 'mars', '0199999933', '', '2020-07-16 04:24:58', '2020-07-16 04:24:58'),
(21, 'tungsweet', 'nganthoi@gmail.com', 'mars', '0199999933', '', '2020-07-16 04:49:58', '2020-07-16 04:49:58'),
(22, 'dũng', 'chuoi0222@gmail.com', 'quận thanh xuân', '0964446181', 'trước khi giao phải gọi trước 1h', '2020-07-20 10:54:04', '2020-07-20 10:54:04'),
(23, 'asdasd', 'phan.trung.99@gmail.com', 'thanh xuân bắc', '099966634', 'trước khi giao phải gọi trước 1h', '2020-07-20 10:56:21', '2020-07-20 10:56:21');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_type` int(10) UNSIGNED DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `warranty` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '36 tháng',
  `unit_price` float DEFAULT NULL,
  `promotion_price` float DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `id_type`, `description`, `warranty`, `unit_price`, `promotion_price`, `image`, `status`, `created_at`, `updated_at`) VALUES
(66, 'Intel Core I3 9100f', 1, 'Là Dòng Core I thế hệ thứ 9 của Intel\r\nCung Cấp cho bạn 1 CPU có 4 nhân 4 luồng cùng turbo 4.2Ghz', '36 tháng', 1850000, 1650000, 'I3 9100f.jpg', 1, '2020-07-19 19:43:43', '2020-07-20 10:30:53'),
(67, 'Intel Core I5 9400f', 5, 'Là Dòng Core I thế hệ thứ 9 của Intel\r\nCung Cấp cho bạn 1 CPU có 6 nhân 6 luồng cùng turbo 4.1Ghz', '36 tháng', 3850000, 3650000, 'i5-9400f.jpg', 0, '2020-07-19 19:43:43', '2020-07-20 05:37:36'),
(69, 'Zotac GTX 1650 4GB', 4, 'VGA ZOTAC GTX 1650 4GB GDDR5 AMP\r\n- Factory Overclocked\r\n- Super Compact\r\n- 4K Ready\r\n- 70mm Twin Fan\r\n- OC Scanner​', '36 tháng', 3950000, 3650000, 'zotac-gtx1650.jpg', 1, NULL, '2020-07-20 10:31:55'),
(70, 'ASUS TUF GTX 1660 Super', 4, NULL, '60 tháng', 6250000, 5800000, 'tuf-gtx1660s.jpg', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `type_products`
--

CREATE TABLE `type_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `type_products`
--

INSERT INTO `type_products` (`id`, `name`) VALUES
(1, 'CPU'),
(2, 'MAIN'),
(3, 'RAM'),
(4, 'GPU-VGA'),
(5, 'SSD'),
(6, 'HDD'),
(7, 'PSU'),
(8, 'Vỏ Case'),
(9, 'Màn Hình'),
(10, 'CPU Cooler'),
(11, 'Gaming Gears'),
(12, 'Các Sản Phẩm Khác');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `phone`, `address`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(7, 'Phan Trung Phu', 'phupt.humg.94@gmail.com', '$2y$10$Mvd0SwKimKXmaWeoRsvRDO0B1ywAfkOV5U4XyYtYq.oYPs0w277yC', '0986420994', 'Ngách 138, Số nhà 62', 1, 'PBvXbSawZ3csj5JBbSExE745jEaNPoLzwdvA8GhuVpxjhQuVTUSg2VXaZYGr', '2019-09-29 05:42:09', '2019-09-29 05:42:09'),
(8, 'nhat nam nguyen tran', 'nam12hn@gmail.com', '$2y$10$/3V.YhhT70w53os1ntIk1.Wg4US.dZ3oxPRM7kngQ60Cpquaav7/y', '123456789', 'nnônno', 1, NULL, '2020-06-08 07:38:50', '2020-06-08 07:38:50'),
(10, 'Nguyễn Thanh Tùng', 'nganthoi@gmail.com', '$2y$10$rj.s0/xCq8pIcRPxdPpx4.BHXabk3emsrZYGDLTS7PG2eJkHVksWm', '0199999933', 'mars', 1, 'r2CS6wjpczYwY3o2lwlVMy1KOAWbgu9wDQansTcKIg8KdSjwzakLnwrId9K7', '2020-06-25 07:02:42', '2020-06-25 07:02:42'),
(11, 'dũng', 'chuoi0222@gmail.com', '$2y$10$qmrFUQIm0gdX.ZxtCvbvS.iZdoRD4Im1PCoclWbQ1.BgUYx3kDcGK', '0964446181', 'quận thanh xuân', 1, 't9b5mLJhBtk4Ot8psfbCeauo6X2Z9V2WteaBTGr8vE9J3uc27q4E0wPaMMFH', '2020-07-20 02:29:10', '2020-07-20 02:29:10');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Chỉ mục cho bảng `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bills_ibfk_1` (`id_customer`);

--
-- Chỉ mục cho bảng `bill_detail`
--
ALTER TABLE `bill_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bill_detail_ibfk_2` (`id_product`);

--
-- Chỉ mục cho bảng `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_id_type_foreign` (`id_type`);

--
-- Chỉ mục cho bảng `type_products`
--
ALTER TABLE `type_products`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT cho bảng `bills`
--
ALTER TABLE `bills`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT cho bảng `bill_detail`
--
ALTER TABLE `bill_detail`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT cho bảng `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT cho bảng `type_products`
--
ALTER TABLE `type_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_id_type_foreign` FOREIGN KEY (`id_type`) REFERENCES `type_products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
